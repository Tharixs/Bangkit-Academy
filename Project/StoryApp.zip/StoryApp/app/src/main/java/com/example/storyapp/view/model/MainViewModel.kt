package com.example.storyapp.view.model

import android.content.SharedPreferences
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.view.response.*
import com.example.storyapp.view.retrofit.ApiConfig
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.http.Multipart

class MainViewModel(private val sharedPreferences: SharedPreferences) : ViewModel() {

    //    token
    private val _token = MutableLiveData<String>()
    val token: LiveData<String> = _token

    private val tokenManager: TokenManager = TokenManager.getInstance(sharedPreferences)

    private val _item = MutableLiveData<List<ListStoryItem>>()
    val items: LiveData<List<ListStoryItem>> = _item

    private val _itemWithLoc = MutableLiveData<List<ListStoryItem>>()
    val itemsWithLoc: LiveData<List<ListStoryItem>> = _itemWithLoc

    private val _detile = MutableLiveData<Story>()
    val detile: LiveData<Story> = _detile


    init {
        _token.value = tokenManager.getToken().toString()
        getStory(_token.value.toString())
    }

    private fun getStory(tokenManager: String) {
        Log.e("token: ", tokenManager)
        val client = ApiConfig.getApiService().getStories("Bearer $tokenManager", null, null, null)
        client.enqueue(object : Callback<StoriesResponse> {
            override fun onResponse(
                call: Call<StoriesResponse>,
                response: Response<StoriesResponse>
            ) {
                if (response.isSuccessful) {
                    _item.value = response.body()?.listStory
                } else {
                    Log.e("onFailure: ", response.message())
                }
            }

            override fun onFailure(call: Call<StoriesResponse>, t: Throwable) {
                Log.e("onFailure2: ", t.message.toString())
            }
        })
    }

    fun getDetileWithid(id: String) {
        val client = ApiConfig.getApiService()
            .getStoriesId("Bearer ${tokenManager.getToken().toString()}", id)
        client.enqueue(object : Callback<DetileStoryResponse> {
            override fun onResponse(
                call: Call<DetileStoryResponse>,
                response: Response<DetileStoryResponse>
            ) {
                if (response.isSuccessful) {
                    _detile.value = response.body()?.story
                } else {
                    Log.e("onFailure: ", response.message())
                }
            }

            override fun onFailure(call: Call<DetileStoryResponse>, t: Throwable) {
                Log.e("onFailure2: ", t.message.toString())
            }
        })
    }

    fun getDataWithLocation(location: Int) {

        val client = ApiConfig.getApiService()
            .getStories("Bearer ${tokenManager.getToken().toString()}", null, null, location)
        client.enqueue(object : Callback<StoriesResponse> {
            override fun onResponse(
                call: Call<StoriesResponse>,
                response: Response<StoriesResponse>
            ) {
                if (response.isSuccessful) {
                    _itemWithLoc.value = response.body()?.listStory
                } else {
                    Log.e("onFailure: ", response.message())
                }
            }

            override fun onFailure(call: Call<StoriesResponse>, t: Throwable) {
                Log.e("onFailure2: ", t.message.toString())
            }
        })
    }

}