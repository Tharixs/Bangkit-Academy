package com.example.jetfood.ui.theme

import android.graphics.Color.rgb
import androidx.compose.ui.graphics.Color

val Purple200 = Color(rgb(255, 230, 199))
val Purple500 = Color(rgb(255, 165, 89))
val Purple700 = Color(rgb(255, 96, 0))
val Teal200 = Color(rgb(69, 69, 69))