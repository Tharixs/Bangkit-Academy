package com.example.jetfood.model

data class OrderFood(
    val food: Food,
    val count: Int
)